/*
 * CPSC 211: Lab 7
 */
package calculator;

/**
 * A test driver for the GUI version of the RPN Calculator
 */
public class CalculatorTestGUI {

    public static void main(String[] args) {
        CalculatorGUI calculator = new CalculatorGUI();
        calculator.showCalculator();
    }
}
